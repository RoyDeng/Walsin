<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ac extends Model
{
    protected $table = 'ac';
	
    public $timestamps = false;
}