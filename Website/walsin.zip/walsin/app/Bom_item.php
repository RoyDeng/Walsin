<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bom_item extends Model
{
    protected $table = 'bom_item';
	
    public $timestamps = false;
}