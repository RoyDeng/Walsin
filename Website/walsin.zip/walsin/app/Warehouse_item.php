<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Warehouse_item extends Model
{
    protected $table = 'warehouse_item';
	
    public $timestamps = false;
}